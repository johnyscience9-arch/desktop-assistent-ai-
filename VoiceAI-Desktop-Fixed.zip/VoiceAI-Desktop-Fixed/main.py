import os
import json
import asyncio
import threading
import tempfile
import winsound
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
import speech_recognition as sr
import edge_tts
from openai import OpenAI

CONFIG_FILE = "config.json"

DEFAULT_CONFIG = {
    "api_key": "",
    "base_url": "https://api.openai.com/v1",
    "model": "gpt-4o-mini",
    "agent_name": "Sarah",
    "business_name": "Bright Smile Dental Clinic",
    "voice": "en-US-AvaNeural",
    "system_prompt": "You are Sarah, a warm, polite, and highly efficient AI receptionist at Bright Smile Dental Clinic. Keep your answers short, natural, and conversational (1-2 sentences max). Clinic hours: Mon-Fri 9 AM to 6 PM. Services: General Checkup ($80), Teeth Whitening ($250), Root Canal ($600). To book an appointment, ask for Patient Name, Reason for visit, and Preferred day/time, then confirm it."
}

VOICES = {
    "English (US) - Ava (Female, Natural)": "en-US-AvaNeural",
    "English (US) - Andrew (Male, Natural)": "en-US-AndrewNeural",
    "English (UK) - Sonia (Female)": "en-GB-SoniaNeural",
    "Bangla (BD) - Nabanita (Female)": "bn-BD-NabanitaNeural",
    "Bangla (BD) - Pradeep (Male)": "bn-BD-PradeepNeural",
    "Bangla (IN) - Tanishaa (Female)": "bn-IN-TanishaaNeural"
}

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {**DEFAULT_CONFIG, **data}
        except Exception:
            pass
    return DEFAULT_CONFIG.copy()

def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4, ensure_ascii=False)

class VoiceAIAssistantApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.config_data = load_config()
        self.is_running = False
        self.conversation_history = []

        self.title(f"{self.config_data['business_name']} - AI Voice Agent Pro")
        self.geometry("920x640")
        self.minsize(820, 560)
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("green")

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self._build_main_area()
        self._build_settings_view()
        self.show_call_view()

    def _build_sidebar(self):
        self.sidebar = ctk.CTkFrame(self, width=220, corner_radius=0, fg_color="#111113")
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_rowconfigure(5, weight=1)

        logo_label = ctk.CTkLabel(self.sidebar, text="🎙️ VoiceAI Pro", font=ctk.CTkFont(size=22, weight="bold"), text_color="#10b981")
        logo_label.grid(row=0, column=0, padx=20, pady=(25, 5))

        sub_label = ctk.CTkLabel(self.sidebar, text="Commercial Edition v1.0", font=ctk.CTkFont(size=12), text_color="#71717a")
        sub_label.grid(row=1, column=0, padx=20, pady=(0, 25))

        self.btn_nav_call = ctk.CTkButton(self.sidebar, text="📞  Live Voice Agent", height=42, corner_radius=10, font=ctk.CTkFont(size=14, weight="bold"), fg_color="#10b981", text_color="#09090b", hover_color="#059669", command=self.show_call_view)
        self.btn_nav_call.grid(row=2, column=0, padx=16, pady=8, sticky="ew")

        self.btn_nav_settings = ctk.CTkButton(self.sidebar, text="⚙️  Business & API Setup", height=42, corner_radius=10, font=ctk.CTkFont(size=14, weight="bold"), fg_color="transparent", text_color="#e4e4e7", hover_color="#27272a", command=self.show_settings_view)
        self.btn_nav_settings.grid(row=3, column=0, padx=16, pady=8, sticky="ew")

        self.btn_clear_chat = ctk.CTkButton(self.sidebar, text="🗑️  Clear Transcript", height=38, corner_radius=10, font=ctk.CTkFont(size=13), fg_color="#18181b", text_color="#a1a1aa", hover_color="#27272a", command=self.clear_transcript)
        self.btn_clear_chat.grid(row=4, column=0, padx=16, pady=8, sticky="ew")

        footer = ctk.CTkLabel(self.sidebar, text="Ready for Client Delivery\nSupports OpenAI & Groq API", font=ctk.CTkFont(size=11), text_color="#52525b")
        footer.grid(row=6, column=0, padx=16, pady=20)

    def _build_main_area(self):
        self.call_frame = ctk.CTkFrame(self, corner_radius=0, fg_color="#09090b")
        self.call_frame.grid_columnconfigure(0, weight=1)
        self.call_frame.grid_rowconfigure(2, weight=1)

        header_frame = ctk.CTkFrame(self.call_frame, fg_color="#18181b", corner_radius=16)
        header_frame.grid(row=0, column=0, padx=24, pady=(24, 12), sticky="ew")
        header_frame.grid_columnconfigure(0, weight=1)

        self.lbl_biz_title = ctk.CTkLabel(header_frame, text=self.config_data["business_name"], font=ctk.CTkFont(size=20, weight="bold"), text_color="#ffffff")
        self.lbl_biz_title.grid(row=0, column=0, padx=20, pady=(14, 2), sticky="w")

        self.lbl_agent_sub = ctk.CTkLabel(header_frame, text=f"AI Receptionist: {self.config_data['agent_name']}  •  24/7 Automated Voice Desk", font=ctk.CTkFont(size=13), text_color="#a1a1aa")
        self.lbl_agent_sub.grid(row=1, column=0, padx=20, pady=(0, 14), sticky="w")

        control_frame = ctk.CTkFrame(self.call_frame, fg_color="#18181b", corner_radius=16)
        control_frame.grid(row=1, column=0, padx=24, pady=8, sticky="ew")
        control_frame.grid_columnconfigure(0, weight=1)

        self.lbl_status = ctk.CTkLabel(control_frame, text="●  System Idle — Click 'Start Voice Session' to begin", font=ctk.CTkFont(size=14, weight="bold"), text_color="#a1a1aa")
        self.lbl_status.grid(row=0, column=0, padx=20, pady=18, sticky="w")

        self.btn_toggle_call = ctk.CTkButton(control_frame, text="🎙️  Start Voice Session", width=200, height=44, corner_radius=12, font=ctk.CTkFont(size=14, weight="bold"), fg_color="#10b981", text_color="#09090b", hover_color="#059669", command=self.toggle_session)
        self.btn_toggle_call.grid(row=0, column=1, padx=20, pady=14, sticky="e")

        self.chat_box = ctk.CTkTextbox(self.call_frame, corner_radius=16, fg_color="#121215", border_width=1, border_color="#27272a", font=ctk.CTkFont(size=14), wrap="word", state="disabled")
        self.chat_box.grid(row=2, column=0, padx=24, pady=(8, 24), sticky="nsew")

    def _build_settings_view(self):
        self.settings_frame = ctk.CTkScrollableFrame(self, corner_radius=0, fg_color="#09090b")
        self.settings_frame.grid_columnconfigure(0, weight=1)

        title = ctk.CTkLabel(self.settings_frame, text="White-Label Business & AI Configuration", font=ctk.CTkFont(size=22, weight="bold"), text_color="#ffffff")
        title.grid(row=0, column=0, padx=24, pady=(24, 4), sticky="w")

        desc = ctk.CTkLabel(self.settings_frame, text="Customize this agent for any client (Dental, Restaurant, Real Estate, E-Commerce) and click Save.", font=ctk.CTkFont(size=13), text_color="#a1a1aa")
        desc.grid(row=1, column=0, padx=24, pady=(0, 20), sticky="w")

        self.entry_api_key = self._add_field(2, "OpenAI / Groq API Key (Required):", self.config_data["api_key"], show="*")
        self.entry_base_url = self._add_field(4, "API Base URL (Default: https://api.openai.com/v1):", self.config_data["base_url"])
        self.entry_model = self._add_field(6, "AI Model Name (e.g., gpt-4o-mini or llama-3.1-8b-instant):", self.config_data["model"])
        self.entry_biz_name = self._add_field(8, "Client Business Name:", self.config_data["business_name"])
        self.entry_agent_name = self._add_field(10, "AI Receptionist Name:", self.config_data["agent_name"])

        lbl_voice = ctk.CTkLabel(self.settings_frame, text="AI Voice Selection (Natural Neural Voices):", font=ctk.CTkFont(size=13, weight="bold"))
        lbl_voice.grid(row=12, column=0, padx=24, pady=(10, 4), sticky="w")

        current_voice_label = next((k for k, v in VOICES.items() if v == self.config_data["voice"]), list(VOICES.keys())[0])
        self.voice_var = ctk.StringVar(value=current_voice_label)
        self.combo_voice = ctk.CTkOptionMenu(self.settings_frame, values=list(VOICES.keys()), variable=self.voice_var, height=38, fg_color="#18181b", button_color="#27272a")
        self.combo_voice.grid(row=13, column=0, padx=24, pady=(0, 12), sticky="ew")

        lbl_prompt = ctk.CTkLabel(self.settings_frame, text="AI Brain / System Instructions (Customize Business Rules & Pricing):", font=ctk.CTkFont(size=13, weight="bold"))
        lbl_prompt.grid(row=14, column=0, padx=24, pady=(10, 4), sticky="w")

        self.txt_prompt = ctk.CTkTextbox(self.settings_frame, height=140, fg_color="#18181b", border_width=1, border_color="#27272a", font=ctk.CTkFont(size=13))
        self.txt_prompt.grid(row=15, column=0, padx=24, pady=(0, 20), sticky="ew")
        self.txt_prompt.insert("1.0", self.config_data["system_prompt"])

        btn_save = ctk.CTkButton(self.settings_frame, text="💾  Save Settings & Apply", height=45, corner_radius=12, font=ctk.CTkFont(size=15, weight="bold"), fg_color="#10b981", text_color="#09090b", hover_color="#059669", command=self.save_settings)
        btn_save.grid(row=16, column=0, padx=24, pady=(0, 30), sticky="ew")

    def _add_field(self, row_idx, label_text, initial_val, show=None):
        lbl = ctk.CTkLabel(self.settings_frame, text=label_text, font=ctk.CTkFont(size=13, weight="bold"))
        lbl.grid(row=row_idx, column=0, padx=24, pady=(8, 4), sticky="w")
        entry = ctk.CTkEntry(self.settings_frame, height=38, fg_color="#18181b", border_color="#27272a", show=show)
        entry.grid(row=row_idx + 1, column=0, padx=24, pady=(0, 8), sticky="ew")
        entry.insert(0, initial_val)
        return entry

    def show_call_view(self):
        self.settings_frame.grid_forget()
        self.call_frame.grid(row=0, column=1, sticky="nsew")
        self.btn_nav_call.configure(fg_color="#10b981", text_color="#09090b")
        self.btn_nav_settings.configure(fg_color="transparent", text_color="#e4e4e7")

    def show_settings_view(self):
        self.call_frame.grid_forget()
        self.settings_frame.grid(row=0, column=1, sticky="nsew")
        self.btn_nav_settings.configure(fg_color="#10b981", text_color="#09090b")
        self.btn_nav_call.configure(fg_color="transparent", text_color="#e4e4e7")

    def save_settings(self):
        selected_voice_code = VOICES.get(self.voice_var.get(), "en-US-AvaNeural")
        self.config_data = {
            "api_key": self.entry_api_key.get().strip(),
            "base_url": self.entry_base_url.get().strip() or "https://api.openai.com/v1",
            "model": self.entry_model.get().strip() or "gpt-4o-mini",
            "business_name": self.entry_biz_name.get().strip() or "AI Business Desk",
            "agent_name": self.entry_agent_name.get().strip() or "Sarah",
            "voice": selected_voice_code,
            "system_prompt": self.txt_prompt.get("1.0", "end").strip()
        }
        save_config(self.config_data)
        self.lbl_biz_title.configure(text=self.config_data["business_name"])
        self.lbl_agent_sub.configure(text=f"AI Receptionist: {self.config_data['agent_name']}  •  24/7 Automated Voice Desk")
        self.title(f"{self.config_data['business_name']} - AI Voice Agent Pro")
        self.conversation_history = []
        messagebox.showinfo("Saved", "Settings saved successfully! Ready for live voice calls.")
        self.show_call_view()

    def clear_transcript(self):
        self.chat_box.configure(state="normal")
        self.chat_box.delete("1.0", "end")
        self.chat_box.configure(state="disabled")
        self.conversation_history = []

    def append_chat(self, sender, message):
        self.chat_box.configure(state="normal")
        self.chat_box.insert("end", f"[{sender}]: {message}\n\n")
        self.chat_box.see("end")
        self.chat_box.configure(state="disabled")

    def update_status(self, text, color="#a1a1aa"):
        self.lbl_status.configure(text=text, text_color=color)

    def toggle_session(self):
        if not self.is_running:
            if not self.config_data.get("api_key"):
                messagebox.showwarning("API Key Missing", "Please enter your OpenAI or Groq API Key in 'Business & API Setup' first.")
                self.show_settings_view()
                return
            self.is_running = True
            self.btn_toggle_call.configure(text="🛑  End Voice Session", fg_color="#ef4444", text_color="#ffffff", hover_color="#dc2626")
            threading.Thread(target=self.voice_loop, daemon=True).start()
        else:
            self.is_running = False
            self.btn_toggle_call.configure(text="🎙️  Start Voice Session", fg_color="#10b981", text_color="#09090b", hover_color="#059669")
            self.update_status("●  Session Ended", "#a1a1aa")

    def speak_text(self, text):
        voice = self.config_data.get("voice", "en-US-AvaNeural")
        temp_file = os.path.join(tempfile.gettempdir(), "voice_ai_reply.wav")

        async def _generate():
            communicate = edge_tts.Communicate(text, voice)
            await communicate.save(temp_file)

        asyncio.run(_generate())
        if not self.is_running:
            return

        try:
            winsound.PlaySound(temp_file, winsound.SND_FILENAME)
        except Exception:
            pass

    def get_ai_response(self, user_text):
        client = OpenAI(api_key=self.config_data["api_key"], base_url=self.config_data["base_url"])
        if not self.conversation_history:
            self.conversation_history.append({"role": "system", "content": self.config_data["system_prompt"]})
        self.conversation_history.append({"role": "user", "content": user_text})

        response = client.chat.completions.create(
            model=self.config_data["model"],
            messages=self.conversation_history,
            max_tokens=150,
            temperature=0.7
        )
        reply = response.choices[0].message.content.strip()
        self.conversation_history.append({"role": "assistant", "content": reply})
        return reply

    def voice_loop(self):
        recognizer = sr.Recognizer()
        recognizer.energy_threshold = 300
        recognizer.dynamic_energy_threshold = True

        greeting = f"Hello! Thank you for calling {self.config_data['business_name']}. This is {self.config_data['agent_name']}. How can I help you today?"
        self.after(0, self.update_status, f"🔊  {self.config_data['agent_name']} is speaking...", "#10b981")
        self.after(0, self.append_chat, self.config_data["agent_name"], greeting)
        try:
            self.speak_text(greeting)
        except Exception as e:
            self.after(0, self.update_status, f"⚠️ Audio Error: {e}", "#ef4444")

        with sr.Microphone() as source:
            recognizer.adjust_for_ambient_noise(source, duration=0.8)
            while self.is_running:
                try:
                    self.after(0, self.update_status, "🎙️  Listening to you... (Speak now)", "#38bdf8")
                    audio = recognizer.listen(source, timeout=5, phrase_time_limit=12)
                    if not self.is_running:
                        break

                    self.after(0, self.update_status, "⏳  Understanding speech...", "#f59e0b")
                    lang_code = "bn-BD" if "bn-" in self.config_data.get("voice", "") else "en-US"
                    user_text = recognizer.recognize_google(audio, language=lang_code)

                    if not user_text.strip():
                        continue

                    self.after(0, self.append_chat, "Customer", user_text)
                    self.after(0, self.update_status, "🧠  Thinking...", "#a855f7")

                    ai_reply = self.get_ai_response(user_text)
                    if not self.is_running:
                        break

                    self.after(0, self.append_chat, self.config_data["agent_name"], ai_reply)
                    self.after(0, self.update_status, f"🔊  {self.config_data['agent_name']} is speaking...", "#10b981")
                    self.speak_text(ai_reply)

                except sr.WaitTimeoutError:
                    continue
                except sr.UnknownValueError:
                    continue
                except Exception as e:
                    err_str = str(e)
                    self.after(0, self.update_status, f"⚠️ Error: {err_str[:60]}", "#ef4444")

if __name__ == "__main__":
    app = VoiceAIAssistantApp()
    app.mainloop()
