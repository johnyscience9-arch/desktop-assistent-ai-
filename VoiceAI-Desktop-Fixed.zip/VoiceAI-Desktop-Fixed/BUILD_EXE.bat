@echo off
title VoiceAI Pro - Auto EXE Builder
color 0A
echo ========================================================
echo    VoiceAI Pro - Commercial Windows EXE Builder
echo ========================================================
echo.
echo [1/3] Cleaning up old build files...
rmdir /s /q build dist 2>nul
echo.
echo [2/3] Installing/Updating required packages (No Pygame)...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo.
echo [3/3] Building standalone Windows .EXE file...
python -m PyInstaller --noconfirm --onefile --windowed --name "VoiceAI_Pro_Agent" --collect-all customtkinter main.py
echo.
echo Copying default config file to dist folder...
copy config.json dist\config.json
echo.
echo ========================================================
echo    SUCCESS! Your EXE is ready inside the 'dist' folder:
echo    dist\VoiceAI_Pro_Agent.exe
echo ========================================================
pause
